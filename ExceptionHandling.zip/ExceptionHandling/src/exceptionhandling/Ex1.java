/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exceptionhandling;

/**
 *
 * @author ASUS
 */
public class Ex1 {
    public static void main(String[] args){
        int a=5; int b=0; int c=0;
            c=a/b;
            System.out.println("Hasil : " + a + " " + b + " " + c);
        }
    }
